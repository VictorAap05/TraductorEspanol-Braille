import { useBrailleTranslator } from './hooks/useBrailleTranslator';
import { BrailleCell } from './components/BrailleCell/BrailleCell';
import './styles.css';

function App() {
  const { textoOriginal, setTextoOriginal, traduccion } = useBrailleTranslator();

  return (
    <div className="app-wrapper">
      <h1 className="app-title">
        Traductor Español - Braille
      </h1>

      {/* Capa de Componentes: Captura de entrada de texto */}
      <div className="input-section">
        <label htmlFor="text-input" className="input-label">
          Ingrese el texto a señalizar:
        </label>
        <textarea
          id="text-input"
          className="input-textarea"
          value={textoOriginal}
          onChange={(e) => setTextoOriginal(e.target.value)}
          placeholder="Escribe aquí números, mayúsculas o vocales acentuadas..."
        />
      </div>

      {/* Contenedor de renderizado iterativo */}
      <div className="braille-output-container">
        {/* Mensaje de estado vacío */}
        {traduccion.length === 0 && (
          <p className="braille-output-empty">
            La vista previa de la señalética aparecerá aquí...
          </p>
        )}

        {/* Iteración gráfica de los cuadratines traducidos */}
        {traduccion.map((nodo, index) => (
          <BrailleCell
            key={index}
            matriz={nodo.matriz}
            caracterOriginal={nodo.esPrefijo ? 'PREF' : nodo.caracterOriginal}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
